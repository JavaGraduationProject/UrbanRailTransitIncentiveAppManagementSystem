const base = {
    url : "http://localhost:8080/ssmzw8q6/"
}
export default base
